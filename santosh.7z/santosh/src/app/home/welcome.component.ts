import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './welcome.component.html'
})
export class WelcomeComponent implements OnInit {
  public pageTitle = 'Welcome';
 mockData: any = {
  min: '5', max: '100'
 };

 currentMaxValue: number;
ngOnInit() {
this.currentMaxValue = this.mockData.max;
}
changedVal(val) {
  console.log('test in parent', val);
  this.currentMaxValue = val;
}
}
