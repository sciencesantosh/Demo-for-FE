import { Component, OnChanges, Input, EventEmitter, Output } from '@angular/core';
import { RangeValueAccessor } from '@angular/forms/src/directives';

@Component({
  selector: 'pm-range-slider',
  templateUrl: './range-slider.component.html',
  styleUrls: ['./range-slider.component.css']
})
export class RangeSliderComponent {
   @Input() data: any;

  @Output() maxValue: EventEmitter<number> =
    new EventEmitter<number>();

valueChange(val) {
console.log('test', val);
this.maxValue.emit(val);
 }
}
